package DCC;

public class ConsultantBillingStrategy implements BillingStrategy {

	public double calculateBill(Patient patient) {
		return 30.0 * 0.2;
	}

}
