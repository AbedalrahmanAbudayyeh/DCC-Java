package DCC;

import java.util.Scanner;

public class DoctorProxy extends Employee

{
    
    Scanner sc = new Scanner(System.in);

    DoctorProxy(String name, String address, int id, int phone) 
    {
        super(name, address, id, phone, "Doctor");
    
    }
    private Doctor doctor;

    public void addMedicine() 
    {

    	doctor.addMedicine();
    }

    public void addTreatmentDescription() 
    {
    	doctor.addTreatmentDescription();
    }
 
}
