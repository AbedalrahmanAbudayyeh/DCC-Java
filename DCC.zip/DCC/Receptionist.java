package DCC;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;

public class Receptionist extends Employee implements Bill {

	Scanner sc = new Scanner(System.in);
	public static Receptionist instance = null;

	private static ArrayList<Patient> Patients = new ArrayList<>();
	private static ArrayList<Appointment> Appointments = new ArrayList<>();

	private Receptionist(String name, String address, int id, int phone) {
		super(name, address, id, phone, "Receptionist");
	}
	private Receptionist() {

	}

	public static Receptionist getInstance(String name, String address, int id, int phone) {
		if (instance == null)
		{
			instance = new Receptionist(name, address, id, phone );
		}
		return instance;
	}



	public void addPatient() 
	{
		Patient patient = new Patient();

		System.out.println("Enter patient name:");
		sc.nextLine();
		patient.setName(sc.nextLine());

		System.out.println("Enter patient address:");
		patient.setAddress(sc.nextLine());

		System.out.println("Enter patient type (ordinary, student, consultant):");
		patient.setType(sc.nextLine());
		
		System.out.println("Enter patient ID:");
		patient.setId(sc.nextInt());

		System.out.println("Enter patient phone number:");
		patient.setPhoneNumber(sc.nextInt());

		Patients.add(patient);
		reserveAppointment(patient);
	}

	public void reserveAppointment(Patient patient) 
	{
		 LocalTime lastReservedTime = LocalTime.of(9, 30);
		if (Appointments.size() >= 17) 
		{
			System.out.println("We are closed now, reserve when in the available times");
		}

		LocalTime openingTime = LocalTime.of(10, 0).plusMinutes(Appointments.size() * 30);
		LocalTime closingTime = openingTime.plusMinutes(30);

		Appointment appointment = new Appointment(openingTime, closingTime, patient);
		Appointments.add(appointment);
		lastReservedTime = closingTime;
	}

	public void printAppointments() 
	{
		for (Appointment appointment : Appointments) 
		{
			System.out.println(	appointment.getPatient().getName() + " " + appointment.getOpeningTime().toString() + "-"+ appointment.getClosingTime().toString());
		}
	}



	public Patient searchPatient(int patientId) 
	{
		for (Patient patient : Patients) {
			if (patient.getId() == patientId) {
				return patient;
			}
		}
		return null;
	}
	@Override
	public void printBill()
	{
	
	    System.out.println("Enter patient ID:");
	    int patientId = sc.nextInt();
	    Patient patient = searchPatient(patientId);

	    if (patient != null) {
	        double billAmount = calculateBill(patient);
	        System.out.println( patient.getName() +  billAmount );
	    } 
	    else
	    {
	        System.out.println( patientId + " not found");
	    }
	}

	public double calculateBill(Patient patient)
	{
		
	    BillingContext billingContext;
	    switch (patient.getType()) 
	    {
	        case "ordinary":
	            billingContext = new BillingContext(new OrdinaryBillingStrategy());
	            return billingContext.executeBillingStrategy(patient);
	        case "student":
	            billingContext = new BillingContext(new StudentBillingStrategy());
	            return billingContext.executeBillingStrategy(patient);
	        case "consultant":
	            billingContext = new BillingContext(new ConsultantBillingStrategy());
	            return billingContext.executeBillingStrategy(patient);
	        default:
	            System.out.println("Invalid patient type but you are going to be an ordinary patient by default.");
	            billingContext = new BillingContext(new OrdinaryBillingStrategy());
	            return billingContext.executeBillingStrategy(patient);
	    }
	}

     
	public static ArrayList<Patient> getPatients()
	{
		return Patients;
	}
	public static ArrayList<Appointment> getAppointments()
	{
		return Appointments;
	}
	public boolean validate_id(int id) 
	{
		if(id >= 0)
		{
			return true;
		}
		return false;
	}
}