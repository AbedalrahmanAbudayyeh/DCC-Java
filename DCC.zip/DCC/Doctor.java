 package DCC;

import java.util.Scanner;

public class Doctor extends Employee
{
	
	Scanner sc = new Scanner(System.in);
	public static Doctor instance = null;

	private Doctor()
	{
		
	}
	private Doctor(String name, String address, int id, int phone) 
	{
		super(name, address, id, phone, "Doctor");
		
	}

	public static Doctor getInstance(String name, String address, int id, int phone) {
		if (instance == null)
		{
			instance = new Doctor(name, address, id, phone);
		}
		return instance;
	}
	

	private Receptionist receptionist;
	
	public void addMedicine()
	{
	    System.out.println("Enter patient ID:");
	    int patientId = sc.nextInt();
	    sc.nextLine(); 

	    Patient patient = receptionist.searchPatient(patientId);

	    if (patient != null) 
	    {
	        System.out.println("Enter medicine name");
	        String medicineName = sc.nextLine();
	        System.out.println("Enter number dose");
	        String dose = sc.nextLine();

	        patient.getMedicines().add(medicineName + " " + dose);
	    } 
	    else 
	    {
	        System.out.println("Patient with ID " + patientId + " not found.");
	    }
	}


	public void addTreatmentDescription() 
	
	{
		System.out.println("enter your id");
		int patientId=sc.nextInt();

	    Patient patient = receptionist.searchPatient(patientId);
	    
	    if (patient != null)
	    {
	    	
	        System.out.println("Enter treatment description for the patient:");
	        String description = sc.next();

	        patient.setTreatmentDescription(description); 
	    } 
	    else 
	    {
	        System.out.println("Patient with ID " + patientId + " not found.");
	    }
	}

	}