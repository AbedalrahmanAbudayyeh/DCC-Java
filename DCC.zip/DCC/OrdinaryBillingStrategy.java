package DCC;

public class OrdinaryBillingStrategy implements BillingStrategy {

	public double calculateBill(Patient patient) {
		return 30.0;
	}
}
