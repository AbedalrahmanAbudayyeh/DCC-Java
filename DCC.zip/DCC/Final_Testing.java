package DCC;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class Final_Testing 
{

    @Test
    void testCalculateBill() 
    {
        Receptionist receptionist = Receptionist.getInstance("Receptionist Name", "Address", 123, 123456789);

        Patient patient1 = new Patient();
        patient1.setType("ordinary");

        double billAmount1 = receptionist.calculateBill(patient1);
        assertEquals(30.0, billAmount1); 
        
        Patient patient2 = new Patient();
        patient2.setType("student");
        double billAmount2 = receptionist.calculateBill(patient2);
        assertEquals(15.0, billAmount2 ); 
       
    }
    
    
    @Test
    void testGetInstance() 
    {
        // Prepare test data
        String name = "Ahmad";
        String address = "amman";
        int id = 2;
        int phoneNumber = 07777777;

        Receptionist receptionist1 = Receptionist.getInstance(name, address, id, phoneNumber);
        Receptionist receptionist2 = Receptionist.getInstance(name, address, id, phoneNumber);

        assertNotNull(receptionist1);
        assertNotNull(receptionist2);
        assertSame(receptionist1, receptionist2);
    }
    @Test
    void testsValidId() {
        Receptionist receptionist = Receptionist.getInstance("ahmad", "amman", 2,07777777);

        boolean result = receptionist.validate_id(100);

        Assertions.assertTrue(result);
    }

  
}
            
    