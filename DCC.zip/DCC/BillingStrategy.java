package DCC;

public interface BillingStrategy 
{
	double calculateBill(Patient patient);
}
