package DCC;

import java.io.FileWriter;
import java.io.IOException;
public class Nurse extends Employee {
	public static Nurse instance = null;

	private Nurse(String name, String address, int id, int phone)
	{
		super(name, address, id, phone, "Nurse");

	}
	private Nurse()
	{
		
	}
	public static Nurse getInstance(String name, String address, int id, int phone) {
		if (instance == null)
		{
			instance = new Nurse(name, address, id, phone);
		}
		return instance;
	}

	 public void generateReport() throws IOException {
	 
	        try {
	            FileWriter fileWriter = new FileWriter("C:\\Users\\User\\OneDrive\\Desktop\\report.txt\\");
	            
	            for (Patient patient : Receptionist.getPatients()) {
	                fileWriter.write(patient.getId() + " " + patient.getName() + "\n");
	                fileWriter.write("Medicines:\n");
	                for (String medication : patient.getMedicines()) 
	                {
	                    fileWriter.write(medication + "\n");
	                }
	                fileWriter.write("Treatment description \n");
	                fileWriter.write(patient.getTreatmentDescription() + "\n");
	                fileWriter.write("Appointment time:\n");
	                for (Appointment appointment : Receptionist.getAppointments()) 
	                {
	                    if (appointment.getPatient().getId() == patient.getId()) 
	                    {
	                        fileWriter.write(appointment.getOpeningTime() + "-" + appointment.getClosingTime() + "\n");
	                        break;
	                    }
	                }
	                fileWriter.write("\n");
	            }

	            fileWriter.close();
	            System.out.println("*************************************************************************************************");
	        }
	        catch (IOException e) 
	        {
	            System.out.println("an IO exception has been found.");
	        }
	
	
	 }
}