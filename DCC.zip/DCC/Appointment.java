package DCC;

import java.time.*;
public class Appointment {
    private LocalTime openingTime;
    private LocalTime closingTime;
    private Patient patient;

    public Appointment(LocalTime openingTime, LocalTime closingTime, Patient patient)
    {
        this.openingTime = openingTime;
        this.closingTime = closingTime;
        this.patient = patient;
    }

    public LocalTime getOpeningTime() {
        return openingTime;
    }

    public LocalTime getClosingTime() {
        return closingTime;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setOpeningTime(LocalTime openingTime) {
		this.openingTime = openingTime;
	}

	public void setClosingTime(LocalTime closingTime) {
		this.closingTime = closingTime;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}
}


