package DCC;

public class BillingContext 
{
	private BillingStrategy billingStrategy;

	public BillingContext(BillingStrategy billingStrategy) {
		this.billingStrategy = billingStrategy;
	}
	public double executeBillingStrategy(Patient patient)
	{
		return billingStrategy.calculateBill(patient);
	}
	
}
