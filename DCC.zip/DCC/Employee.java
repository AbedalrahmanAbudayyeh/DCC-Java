package DCC;

public class Employee{
	private String name;
	private String address;
	private int id;
	private int phone;
	private String jobDescription;
	
	public Employee() {
		
	}
	
	public Employee(String name, String address, int id, int phone, String jobDescription) {
		this.name = name;
		this.address = address;
		this.id = id;
		this.phone = phone;
		this.jobDescription= jobDescription;
		     
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getJobDescription() {
		return jobDescription;
	}


	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	
}
