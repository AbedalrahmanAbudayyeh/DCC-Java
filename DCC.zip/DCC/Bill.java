package DCC;

public interface Bill 
{
	
	public void printBill();

	
}
