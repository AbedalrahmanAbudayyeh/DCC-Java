package DCC;

public class StudentBillingStrategy implements BillingStrategy {

	@Override
	public double calculateBill(Patient patient) {
		return 30.0 * 0.5;
	}

}
