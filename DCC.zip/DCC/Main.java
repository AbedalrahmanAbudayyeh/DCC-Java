package DCC;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {
	    Receptionist receptionist = Receptionist.getInstance("khalid", "amman", 1234, 534535);
	    DoctorProxy Doctor = new DoctorProxy("ahmad", "aqaba", 2, 78465);
	    Nurse nurse =  Nurse.getInstance("otaqi", "irbid", 555, 77873311);
	    while (true)
	    {
		    Scanner sc = new Scanner(System.in);

	        System.out.println("Enter job Description (Doctor, Nurse, Receptionist)");
	        String job = sc.nextLine();

	        if (receptionist.getJobDescription().equals(job)) 
	        {
	        
	                System.out.println("Enter 1 to add a patient");
	                System.out.println("Enter 2 to print a bill for a patient");
	                System.out.println("Enter 3 to print appointments");
	                int operation = sc.nextInt();
	                switch (operation) 
	                {
	                    case 1:
	                    	
	                    	receptionist.addPatient();

	                        break;
	                    case 2:
	                    	receptionist.printBill();

	                        break;
	                    case 3:
	                    	receptionist.printAppointments();
	                        break;
	                    default:
	                        System.out.println("Invalid number.");
	                        break;
	                  }
	        } 
	        else if
	        (Doctor.getJobDescription().equals(job))
	        	
	        {
	        	System.out.println("Enter 1 to add medicine");
	        	System.out.println("Enter 2 to add treatmetnt description");
	        	int operation=sc.nextInt();
	        	 sc.nextLine();
	        	 
	        	 switch (operation) {
				case 1: Doctor.addMedicine();
	
					break;
					case 2:Doctor.addTreatmentDescription();
				break;
				default:
                    System.out.println("Invalid number.");
					break;
				}
	        	
	        } 
	        else if (nurse.getJobDescription().equals(job))
	        {
	            
	        	 System.out.println("Enter 1 to generate a report for a patient");
	        	    int operation = sc.nextInt();
	        	    sc.nextLine();	
	        	    if (operation== 1)
	        	    {
	        	    	nurse.generateReport();
	        	    }
	        	    else
	        	    {
                        System.out.println("Invalid number.");
	        	    }
	        } 
	 
	        else {
	            System.out.println("Invalid job description.");
	        }
	    }
	}
}