package DCC;
import java.util.ArrayList;

public class Patient {

	private String name;
	private String address;
	private int id;
	private int phone;
	private String type;
	private String treatmentDescription;
	private ArrayList<String> medicines = new ArrayList<>();
	public Patient() {
		
	}

	public Patient(String name, String address, int id, int phone, String type) 
	{
		this.name = name;
		this.address = address;
		this.id = id;
		this.phone = phone;
		this.type = type;
	}
		
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getPhoneNumber() {
		return phone;
	}
	
	public void setPhoneNumber(int phone) {
		this.phone = phone;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getTreatmentDescription() {
		return treatmentDescription;
	}
	
	public void setTreatmentDescription(String treatmentDescription) {
		this.treatmentDescription = treatmentDescription;
	}
	
	public ArrayList<String> getMedicines() {
		return medicines;
	}
	
	public void setMedicines(ArrayList<String> medicines) {
		this.medicines = medicines;
	}
	
}